#include <string>
#include "Procode.h" 

using namespace ImGui;

bool ise::tab(const char* label, bool selected ) {
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow( );

    ImGuiID id = window->GetID( label );

    ImVec2 p = window->DC.CursorPos;
    ImVec2 size( { window->Size.x, 15 } );
    ImRect bb( p, p + size );

    ItemSize( bb );
    ItemAdd( bb, id );

    bool hovered, held;
    bool pressed = ButtonBehavior( bb, id, &hovered, &held );

    float anim = ImTricks::Animations::FastFloatLerp( std::string( label ).append( "tab.anim" ), selected, 0.f, 1.f, 0.1f );
    auto col = ImTricks::Animations::FastColorLerp( GetColorU32( ImGuiCol_Text), AccentColor, anim );

    if ( pressed )
        content_anim = 0.f;

  
    PushStyleColor( ImGuiCol_Text, col.Value );
    RenderText( { bb.Min.x + 20, bb.GetCenter( ).y - CalcTextSize( label ).y / 2 }, label );
    PopStyleColor( );
    return pressed;
}
