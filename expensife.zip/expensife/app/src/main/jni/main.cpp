#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include "Procode.h"
#include "Includes.h"
#include "Fonts/byte_array.h"
#include "Fonts/days2.h"
#include "Fonts/Fonts.h"
#include "dobby/dobby.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>
#include "Init/monoString.h"
#include "Includes/obfuscate.h"

float dpiscale = 1;
int screenWidth = 0;
int screenHeight = 0;
bool g_Initialized = false;
ImGuiWindow* g_window = NULL;  
ImFont*logo;
ImFont*Days2;
ImFont*NewFont;
ImFont* combo_arrow;
ImVec4 AccentColor = ImColor(105, 0, 198);
JavaVM* publicVM;
JNIEnv* publicEnv;
#define libName ("libil2cpp.so")

extern "C" {
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_init(JNIEnv* env, jclass cls);
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_resize(JNIEnv* env, jobject obj, jint width, jint height);
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_step(JNIEnv* env, jobject obj);
	JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_imgui_Shutdown(JNIEnv* env, jobject obj);
	JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_MotionEventClick(JNIEnv* env, jobject obj,jboolean down,jfloat PosX,jfloat PosY);
	JNIEXPORT jstring JNICALL Java_com_mycompany_application_GLES3JNIView_getWindowRect(JNIEnv *env, jobject thiz);
	JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_real(JNIEnv* env, jobject obj, jint width, jint height);
};

JNIEXPORT void JNICALL
Java_com_mycompany_application_GLES3JNIView_init(JNIEnv* env, jclass cls) {

    //SetUpImGuiContext
    if(g_Initialized) return ;
	IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
	
	//Set ImGui Style
    ImGui::StyleColorsDark();
	
	ImFontConfig font_cfg;
    font_cfg.SizePixels = 22.0f;
    io.Fonts->AddFontFromMemoryTTF(Intermedium, sizeof(Intermedium), 22.0f, &font_cfg); 
	
	Days2 = io.Fonts->AddFontFromMemoryTTF(Intermedium, sizeof(Intermedium), 30.0f);
	logo = io.Fonts->AddFontFromMemoryTTF(clarityfont, sizeof(clarityfont), 50.0f);
	combo_arrow = io.Fonts->AddFontFromMemoryTTF(combo, sizeof(combo), 9.0f);
	
    // Setup Platform/Renderer backends
    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init("#version 300 es");	
	ImGui::GetStyle().ScaleAllSizes(3.0f);
   
    g_Initialized=true;
}

JNIEXPORT void JNICALL
Java_com_mycompany_application_GLES3JNIView_resize(JNIEnv* env, jobject obj, jint width, jint height) {
	screenWidth = (int) width;
    screenHeight = (int) height;
	glViewport(0, 0, width, height);
	ImGuiIO &io = ImGui::GetIO();
    io.ConfigWindowsMoveFromTitleBarOnly = true;
    io.IniFilename = NULL;
	ImGui::GetIO().DisplaySize = ImVec2((float)width, (float)height);
}
bool openMenu = true;
bool pressed = true;
bool notpressed = false;
int alphaMenu;
float endf;
int endt;
int comboas;
const char* type[] = { "Type", "Types", "Select" };

void AddColorPicker(const char* name, ImVec4 &color, bool prd = false, bool* rainbow = nullptr, bool* pulse = nullptr, bool* dark = nullptr) {
    ImGuiColorEditFlags misc_flags = ImGuiColorEditFlags_AlphaPreview;
    static ImVec4 backup_color;
	auto s = ImGui::GetWindowDrawList();
	
    bool open_popup = ImGui::ColorButton((std::string(name) + std::string(("##3b"))).c_str(), color, misc_flags,ImVec2(30,30));
	
    if (open_popup) {
        ImGui::OpenPopup(name);
        backup_color = color;
    }
    if (ImGui::BeginPopup(name)) {
       // ImGui::Text(("%s"), std::string(name).c_str());
        ImGui::ColorPicker4(("##picker"), (float *) &color,misc_flags |ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar |ImGuiColorEditFlags_NoOptions );
        if (prd) {
            if (rainbow) ImGui::Checkbox(("rainbow"), rainbow);
            if (pulse) ImGui::Checkbox(("pulse"), pulse);
            if (dark) ImGui::Checkbox(("dark"), dark);
        }
        ImGui::EndPopup();
    }
}

void BeginDraw() {
	//стили
    ImGuiIO &io = ImGui::GetIO();
	ImGuiStyle& s = ImGui::GetStyle();
	ImGuiContext& g = *GImGui;
	s.Colors[ImGuiCol_Border] = ImColor(128,128,128);
	s.Colors[ImGuiCol_CheckMark] = ImColor(0,0,0);
	s.Colors[ImGuiCol_Button] = ImColor(0,0,0,0);
	s.Colors[ImGuiCol_ButtonActive] = ImColor(255,255,255,50);
	s.Colors[ImGuiCol_ButtonHovered] = ImColor(255,255,255,50);
	s.Colors[ImGuiCol_Header] = AccentColor;
	s.Colors[ImGuiCol_HeaderActive] = AccentColor;
	s.WindowBorderSize = 0;
	s.ChildRounding = 6;
	s.ChildBorderSize = 1;
	s.FrameBorderSize = 1.f;
	s.FrameRounding = 6;
	
	ImGui::PushStyleColor(ImGuiCol_WindowBg, ImColor(0, 0, 0, 0).Value);
    ImGui::PushStyleColor(ImGuiCol_Border, ImColor(0, 0, 0, 0).Value);
    ImGui::GetStyle().WindowMinSize = ImVec2(0, 0);
    ImGui::SetNextWindowPos(
    ImVec2(screenWidth / 2 - 100 * dpiscale, screenHeight - 60 * dpiscale));
    ImGui::SetNextWindowSize(ImVec2(355, 75) * dpiscale);
    ImGui::Begin("##", nullptr,
    ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
    ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoResize);
    if (ImGui::InvisibleButton("##", ImGui::GetWindowSize()))
    openMenu = !openMenu;
    ImGui::GetWindowDrawList()->AddRectFilledMultiColor(
    ImVec2(screenWidth / 2 - 135 * dpiscale, screenHeight - 15 * dpiscale),
    ImVec2(screenWidth / 2 + 135 * dpiscale, screenHeight - 10 * dpiscale),
    ImColor(0,0,0),ImColor(AccentColor),ImColor(0, 0, 0),ImColor(AccentColor));
    ImGui::PopStyleColor(2); 
    if(!openMenu)
    return;
            
    g_window = ImGui::GetCurrentWindow();
	
    ImGui::End();
	
	if (openMenu) {
	bool openMenu1 = true;
	if (!openMenu) {
	openMenu1 = false;
	}
	
	
	//бегин
	ImGui::PushStyleColor(ImGuiCol_WindowBg, ImColor(6,1,21, 255).Value);
	ImGui::Begin("ImGay",nullptr,ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar);
	ImGui::SetWindowSize(ImVec2(1000,600));
	ImGui::PopStyleColor(1);
	
    g_window = ImGui::GetCurrentWindow();
	
	//рендер
	auto draw = ImGui::GetWindowDrawList();
    auto pos = ImGui::GetWindowPos();
	
	if (openMenu1) {
        alphaMenu += 1;
        if (alphaMenu >= 160) {
			alphaMenu = 160;
            openMenu1 = false;
        }
		}else{
		alphaMenu -= 1;
		if (alphaMenu <= 0) {
			alphaMenu = 0;
		}
     }
	
    ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0,0), ImVec2(screenWidth,screenHeight), ImColor(0, 0, 0, alphaMenu));
	draw->AddRectFilledMultiColor(ImVec2(pos.x,pos.y), ImVec2(pos.x + 1000,pos.y + 600),ImColor(0,0,0,0),ImColor(AccentColor),ImColor(0, 0, 0,0),ImColor(AccentColor));
	
	//табы
	ImGui::SetCursorPos(ImVec2(20,90));
    ImGui::BeginGroup(); {
	ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(0,65));
	ImGui::PushFont(logo);
    if ( ise::tab("B", tab == 0 ) ) tab = 0;
    if ( ise::tab("C", tab == 1 ) ) tab = 1;
    if ( ise::tab("D", tab == 2 ) ) tab = 2;
    if ( ise::tab("E", tab == 3 ) ) tab = 3;
    if ( ise::tab("F", tab == 4 ) ) tab = 4;
	if ( ise::tab("G", tab == 5 ) ) tab = 5;
    }
	ImGui::PopFont();
    ImGui::PopStyleVar(1);
    ImGui::EndGroup();
	
	//anim
	
	if (tab == 0) {
	//child 0
	ImGui::SetCursorPos(ImVec2(130,20));
	ImGui::BeginChild("Child 0",ImVec2(415,560),true,ImGuiWindowFlags_AlwaysUseWindowPadding | ImGuiWindowFlags_NoScrollbar);
	ImGui::PushStyleColor(ImGuiCol_ChildBg, g.Style.Colors[ImGuiCol_ChildBg] = ImColor(16,15,18,175));
	ImGui::PopStyleColor(1);
	//сюда
	ImGui::SetCursorPos(ImVec2(20,20));
	ImGui::BeginGroup(); {
	
	ImGui::PushFont(Days2);
	ImGui::Text("Expensive");
	ImGui::PopFont();
		
	ImGui::Checkbox("Checkbox Enabled", &pressed);
	ImGui::SameLine();
    AddColorPicker(("Color"), *(ImVec4 *) &AccentColor);
    ImGui::Checkbox("Checkbox Disabled", &notpressed);
	if (ImGui::Button("Button Expamle", ImVec2(375,50))) {
    // Действия при нажатии на кнопку
    }
	ImGui::SliderFloat(("Float Slider"), &endf, -100, 100);
	ImGui::SliderInt(("Int Slider"), &endt, -100, 100);

	ImGui::Combo("Combo", &comboas, type, IM_ARRAYSIZE(type));
	}
	ImGui::EndGroup();
	ImGui::EndChild();
	
	//child 1
	ImGui::SetCursorPos(ImVec2(565,20));
	ImGui::BeginChild("Child 1",ImVec2(415,560),true,ImGuiWindowFlags_AlwaysUseWindowPadding | ImGuiWindowFlags_NoScrollbar);
	ImGui::PushStyleColor(ImGuiCol_ChildBg, g.Style.Colors[ImGuiCol_ChildBg] = ImColor(16,15,18,175));
	ImGui::PopStyleColor(1);
	//сюда
	
	ImGui::EndChild();
	
	}
	
	ImGui::End();
    }
}

//проверка подписки
static void HelpMarker(const char* desc)
{   ImGui::PushStyleColor(ImGuiCol_TextDisabled, ImColor(AccentColor).Value);
    ImGui::TextDisabled("{?}");
	ImGui::PopStyleColor(1);
    if (ImGui::IsItemHovered())
    {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
        ImGui::TextUnformatted(desc);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}

int alphaBg;
bool alphaBut = true;
bool buttin = false;
void (*OpenUrl)(monoString* expensive);
void SubscribeCheck() {
	if (buttin) {
	 ImGuiIO &io = ImGui::GetIO();
	 ImGuiStyle& s = ImGui::GetStyle();
	 ImGuiContext& g = *GImGui;
	 s.Colors[ImGuiCol_Border] = ImColor(128,128,128);
	 s.Colors[ImGuiCol_CheckMark] = ImColor(0,0,0);
	 s.Colors[ImGuiCol_Button] = ImColor(0,0,0,0);
	 s.Colors[ImGuiCol_ButtonActive] = ImColor(255,255,255,50);
	 s.Colors[ImGuiCol_ButtonHovered] = ImColor(255,255,255,50);
	 s.Colors[ImGuiCol_Header] = AccentColor;
	 s.Colors[ImGuiCol_HeaderActive] = AccentColor;
	 s.WindowBorderSize = 0;
	 s.ChildRounding = 6;
	 s.ChildBorderSize = 1;
	 s.FrameBorderSize = 1.f;
	 s.FrameRounding = 6;

	 ImGui::PushStyleColor(ImGuiCol_WindowBg, ImColor(6,1,21, 255).Value);
     ImGui::SetNextWindowPos(ImVec2(screenWidth / 2.5f, screenHeight / 2.5f));
	 ImGui::SetNextWindowSize(ImVec2(500, 200), ImGuiCond_Once);
     if (ImGui::Begin(OBFUSCATE("Free Client"), NULL,
     ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
     ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize)) {
	 ImGui::PopStyleColor(1);
	 
	 g_window = ImGui::GetCurrentWindow();
	 
	 auto draw = ImGui::GetWindowDrawList();
     auto pos = ImGui::GetWindowPos();
	 
	 if (alphaBut) {
        alphaBg += 1;
        if (alphaBg >= 160) {
            alphaBut = false;
        }
     }
	 
	 ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0,0), ImVec2(screenWidth,screenHeight), ImColor(0, 0, 0, alphaBg));
	 draw->AddRectFilledMultiColor(ImVec2(pos.x,pos.y), ImVec2(pos.x + 500,pos.y + 200),ImColor(0,0,0,0),ImColor(AccentColor),ImColor(0, 0, 0,0),ImColor(AccentColor));
	
	 std::string text = "Subscribe System";
     auto textWidth = ImGui::CalcTextSize(text.c_str()).x;
	 auto windowWidth = ImGui::GetWindowSize().x;
     ImGui::SetCursorPosX((windowWidth - 80 - textWidth) * 0.5f);
	 ImGui::SetCursorPosY(20);
	 ImGui::PushFont(Days2);
	 ImGui::TextColored(AccentColor, text.c_str());
	 ImGui::SameLine();
	 HelpMarker("Subscribe to the channel to continue playing with the cheat!");
	 ImGui::PopFont();
	 
	 ImGui::Spacing();
	 ImGui::Spacing();
	 ImGui::Spacing();
	 ImGui::Spacing();
	 ImGui::Spacing();
	 ImGui::SetCursorPosX(20);
	 
	 if (ImGui::Button(OBFUSCATE("Subscribe"), ImVec2(460,50))) {
		OpenUrl(il2cpp_string_new("https://t.me/Expensive1337"));
        buttin = false;
		alphaBut = false;
		if (!alphaBut) {
		alphaBg -= 1;
	 }
     }
	 
	 
	 }
	 ImGui::End();
	 }
}

//ватермарк
bool watermark = true;
void Watermark() {
	
	if(watermark) {
	
	ImGui::Begin("##WildWater", NULL, ImGuiWindowFlags_::ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_::ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_::ImGuiWindowFlags_NoBackground); {
		
	auto draw = ImGui::GetForegroundDrawList();
	auto pos = ImGui::GetWindowPos();
		
	draw->AddRectFilledMultiColorRounded(ImVec2(pos.x,pos.y), ImVec2(pos.x + 300,pos.y + 50),ImColor(0,0,0,0),ImColor(0,0,0),ImColor(AccentColor),ImColor(0,0,0),ImColor(AccentColor),20.f);
	
	}
	}
	ImGui::End();
}

//поддержка 2 окон

bool HandleInputEvent(JNIEnv *env, int motionEvent, int x, int y, int p);

typedef enum { TOUCH_ACTION_DOWN = 0, TOUCH_ACTION_UP, TOUCH_ACTION_MOVE } TOUCH_ACTION;

typedef struct {
    TOUCH_ACTION action;
    float x;
    float y;
    int pointers;
    float y_velocity;
    float x_velocity;
}TOUCH_EVENT;
 TOUCH_EVENT g_LastTouchEvent;

bool  HandleInputEvent(JNIEnv *env, int motionEvent, int x, int y, int p) {
    float velocity_y = (float)((float)y - g_LastTouchEvent.y) / 100.f;
    g_LastTouchEvent = {.action = (TOUCH_ACTION) motionEvent, .x = static_cast<float>(x), .y = static_cast<float>(y), .pointers = p, .y_velocity = velocity_y};
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos.x = g_LastTouchEvent.x;
    io.MousePos.y = g_LastTouchEvent.y;
    if(motionEvent == 2){
        if (g_LastTouchEvent.pointers > 1) {
            io.MouseWheel = g_LastTouchEvent.y_velocity;
            io.MouseDown[0] = false;
        }
        else {
            io.MouseWheel = 0;
        }
    }
    if(motionEvent == 0){
        io.MouseDown[0] = true;
    }
    if(motionEvent == 1){
        io.MouseDown[0] = false;
    }
    return true;
}

bool (*old_nativeInjectEvent )(JNIEnv*, jobject ,jobject event);
bool hook_nativeInjectEvent(JNIEnv* env, jobject instance,jobject event){
        jclass MotionEvent = env->FindClass(("android/view/MotionEvent"));
        if(!MotionEvent){

        }
        
        if(!env->IsInstanceOf(event, MotionEvent)){
            return old_nativeInjectEvent(env, instance, event);
        }
        //LOGD("Processing Touch Event!");
        jmethodID id_getAct = env->GetMethodID(MotionEvent, ("getActionMasked"), ("()I"));
        jmethodID id_getX = env->GetMethodID(MotionEvent, ("getX"), ("()F"));
        jmethodID id_getY = env->GetMethodID(MotionEvent, ("getY"), ("()F"));
        jmethodID id_getPs = env->GetMethodID(MotionEvent, ("getPointerCount"), ("()I"));
        HandleInputEvent(env, env->CallIntMethod(event, id_getAct),env->CallFloatMethod(event, id_getX), env->CallFloatMethod(event, id_getY), env->CallIntMethod(event, id_getPs));
        if (!ImGui::GetIO().MouseDownOwnedUnlessPopupClose[0]){
            return old_nativeInjectEvent(env, instance, event);
        }
        return false;
}

jint (*old_RegisterNatives )(JNIEnv*, jclass, JNINativeMethod*,jint);
jint hook_RegisterNatives(JNIEnv* env, jclass destinationClass, JNINativeMethod* methods,
                          jint totalMethodCount){

    int currentNativeMethodNumeration;
    for (currentNativeMethodNumeration = 0; currentNativeMethodNumeration < totalMethodCount; ++currentNativeMethodNumeration )
    {
		
		if (!strcmp(methods[currentNativeMethodNumeration].name, ("nativeInjectEvent")) ){
            DobbyHook(methods[currentNativeMethodNumeration].fnPtr, (void*)hook_nativeInjectEvent, (void **)&old_nativeInjectEvent);
        }
        
    }
    //SearchActivity(env);
    return old_RegisterNatives(env, destinationClass, methods, totalMethodCount);
}

void StartBackend(JNIEnv* env){
    //Input
    DobbyHook((void*)env->functions->RegisterNatives, (void*)hook_RegisterNatives, (void **)&old_RegisterNatives);
}

JNIEXPORT void JNICALL
Java_com_mycompany_application_GLES3JNIView_step(JNIEnv* env, jobject obj) {
    
	ImGuiIO& io = ImGui::GetIO();
	
    static bool show_MainMenu_window = true;

	//Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(screenWidth,  screenHeight);//？Settings window
    ImGui::NewFrame();       
    
	if (show_MainMenu_window) {
		SubscribeCheck();
		Watermark();
		if (!buttin) {
		BeginDraw();
		}
	}
	
    ImGui::Render();
	glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_imgui_Shutdown(JNIEnv* env, jobject obj){
    if (!g_Initialized)
        return;
     // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    g_Initialized=false;
}

JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_MotionEventClick(JNIEnv* env, jobject obj,jboolean down,jfloat PosX,jfloat PosY){
	ImGuiIO & io = ImGui::GetIO();
	io.MouseDown[0] = down;
	io.MousePos = ImVec2(PosX,PosY);
}

JNIEXPORT jstring JNICALL Java_com_mycompany_application_GLES3JNIView_getWindowRect(JNIEnv *env, jobject thiz) {
    //get drawing window
    // TODO: accomplish getWindowSizePos()
    char result[256]="0|0|0|0";
    if(g_window){
        sprintf(result,"%d|%d|%d|%d",(int)g_window->Pos.x,(int)g_window->Pos.y,(int)g_window->Size.x,(int)g_window->Size.y);
    }
    return env->NewStringUTF(result);
}

void *cheat(void *) {
 do {
     sleep(1);
  } while (!isLibraryLoaded(libName));
   
  sleep(5);
  
  //сюда оффсетики
  OpenUrl = (void (*) (monoString*)) getAbsoluteAddress("libil2cpp.so", 0x2320454);
  
return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    publicVM = vm;
    publicEnv = globalEnv;
    pthread_t ptid;
    pthread_create(&ptid, NULL, cheat, NULL);
	StartBackend(globalEnv);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}

