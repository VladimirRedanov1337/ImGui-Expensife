#pragma once

#include <cstdint>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <map>
#include "imgui_tricks.hpp"
#include "imgui.h"
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui_internal.h" 


inline float content_anim = 0.f;
inline int tab = 0;
extern ImVec4 AccentColor;

namespace ise {
bool tab(const char* label, bool selected );
}
